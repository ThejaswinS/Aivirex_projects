# VoiceBudget

### Introduction
Voice based budget control , as name suggests this helps in tracking the budget using voice and data is stored in excel sheet which can be used to view in future.
only set of commands is recognized and operation performed.

Example set of commands namely,
- I got Rs 5000 as my salary
- I got 1000 from my friend
- I spent 400 on shoes
- I gave 300 to waiter
- my educational expense include 3000
- I paid 1000 to shop owner

### Dependencies
Run this command in your shell make sure requirements file is in path
 
    pip install -r requirements.txt
   
Finally You are ready to go!!


### Screenshot
| ![Screenshot 2021-07-05 092015](https://user-images.githubusercontent.com/52855622/124416417-93c46a80-dd74-11eb-826d-e8a6a2a2bbbd.png) | ![image](https://user-images.githubusercontent.com/52855622/124549087-49162180-de4c-11eb-8936-2fc8206da402.png) |
| :------------------------------------------------------------------------------------------: | :---------------------------------------------------------------------------------------------------------------------------------------------------------: |
|                    **Query printed in terminal**                                    |                               **Data stored in Excel**                                    | 
 

![image](https://user-images.githubusercontent.com/52855622/124550291-14a36500-de4e-11eb-9504-356191c93739.png)

